GRANT ALL PRIVILEGES ON moviedb.* TO testuser@localhost IDENTIFIED BY 'testpass';
FLUSH PRIVILEGES;
